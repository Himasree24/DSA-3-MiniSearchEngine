package com.searchengine;

import java.util.ArrayList;
import java.util.HashMap;

public class InvertedIndex {

    private HashMap<String, ArrayList<Integer>> index;

    public InvertedIndex() {
        index = new HashMap<>();
    }

    public void addWord(
            String word,
            int documentId) {

        if (word == null || word.isEmpty()) {
            return;
        }

        word = word.toLowerCase();

        if (!index.containsKey(word)) {
            index.put(
                    word,
                    new ArrayList<Integer>()
            );
        }

        ArrayList<Integer> documents =
                index.get(word);

        if (!documents.contains(documentId)) {
            documents.add(documentId);
        }
    }

    public ArrayList<Integer> search(
            String word) {

        if (word == null) {
            return new ArrayList<>();
        }

        word = word.toLowerCase().trim();

        if (index.containsKey(word)) {
            return new ArrayList<>(
                    index.get(word)
            );
        }

        return new ArrayList<>();
    }

    public int size() {
        return index.size();
    }
}