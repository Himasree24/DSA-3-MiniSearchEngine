package com.searchengine;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Ranker scores and orders documents based on Term Frequency - Inverse Document Frequency (TF-IDF).
 *
 * DSA Concepts Used:
 * - TF-IDF Scoring: Evaluates how important each word in a multi-word query is
 *   to a document relative to the whole corpus.
 * - Bubble Sort: DSA sorting algorithm to order ranked documents in descending order of score.
 */
public class Ranker {

    private TextProcessor processor;
    private TFIDF tfidf;

    public Ranker() {
        this.processor = new TextProcessor();
        this.tfidf = new TFIDF();
    }

    public ArrayList<WebDocument> rank(
            String query,
            ArrayList<WebDocument> documents) {

        ArrayList<WebDocument> ranked = new ArrayList<>();

        if (query == null
                || query.trim().isEmpty()
                || documents == null
                || documents.isEmpty()) {
            return ranked;
        }

        // Tokenize multi-word query (e.g. "machine learning" -> ["machine", "learning"])
        String[] queryTerms = processor.process(query);

        if (queryTerms.length == 0) {
            return ranked;
        }

        int totalDocuments = documents.size();

        // Pre-process words for each document
        ArrayList<String[]> docWordsList = new ArrayList<>();
        for (WebDocument document : documents) {
            docWordsList.add(processor.process(document.getText()));
        }

        // DSA: Calculate IDF for each query term
        HashMap<String, Double> idfMap = new HashMap<>();

        for (String term : queryTerms) {
            if (idfMap.containsKey(term)) {
                continue;
            }

            int containingTerm = 0;
            for (String[] docWords : docWordsList) {
                for (String word : docWords) {
                    if (word.equals(term)) {
                        containingTerm++;
                        break;
                    }
                }
            }

            double idf = tfidf.calculateIDF(totalDocuments, containingTerm);
            idfMap.put(term, idf);
        }

        ArrayList<Double> scores = new ArrayList<>();

        // Calculate combined TF-IDF score for each document
        for (int i = 0; i < totalDocuments; i++) {
            String[] words = docWordsList.get(i);
            double totalScore = 0.0;

            for (String term : queryTerms) {
                int count = 0;
                for (String word : words) {
                    if (word.equals(term)) {
                        count++;
                    }
                }

                double tf = tfidf.calculateTF(count, words.length);
                double idf = idfMap.getOrDefault(term, 0.0);
                totalScore += tfidf.calculateTFIDF(tf, idf);
            }

            if (totalScore > 0) {
                ranked.add(documents.get(i));
                scores.add(totalScore);
            }
        }

        // DSA: Bubble Sort by score in descending order
        for (int i = 0; i < scores.size() - 1; i++) {
            for (int j = 0; j < scores.size() - i - 1; j++) {
                if (scores.get(j) < scores.get(j + 1)) {
                    double tempScore = scores.get(j);
                    scores.set(j, scores.get(j + 1));
                    scores.set(j + 1, tempScore);

                    WebDocument tempDocument = ranked.get(j);
                    ranked.set(j, ranked.get(j + 1));
                    ranked.set(j + 1, tempDocument);
                }
            }
        }

        return ranked;
    }

    public double getScore(
            String query,
            WebDocument document,
            ArrayList<WebDocument> documents) {

        if (query == null || document == null || documents == null || documents.isEmpty()) {
            return 0.0;
        }

        String[] queryTerms = processor.process(query);
        if (queryTerms.length == 0) {
            return 0.0;
        }

        String[] docWords = processor.process(document.getText());
        double totalScore = 0.0;

        for (String term : queryTerms) {
            int containingTerm = 0;
            for (WebDocument doc : documents) {
                String[] words = processor.process(doc.getText());
                for (String word : words) {
                    if (word.equals(term)) {
                        containingTerm++;
                        break;
                    }
                }
            }

            double idf = tfidf.calculateIDF(documents.size(), containingTerm);

            int count = 0;
            for (String word : docWords) {
                if (word.equals(term)) {
                    count++;
                }
            }

            double tf = tfidf.calculateTF(count, docWords.length);
            totalScore += tfidf.calculateTFIDF(tf, idf);
        }

        return totalScore;
    }
}