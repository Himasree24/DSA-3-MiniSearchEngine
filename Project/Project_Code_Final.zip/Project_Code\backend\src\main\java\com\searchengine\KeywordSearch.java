package com.searchengine;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * KeywordSearch retrieves documents matching words in the user query using
 * an Inverted Index data structure.
 *
 * DSA Concepts Used:
 * - Inverted Index (HashMap<String, ArrayList<Integer>>): O(1) average lookup
 *   from a word to the list of document IDs containing it.
 * - Multi-term frequency scoring & Bubble Sort: Ranks documents that contain
 *   more matching keywords higher.
 */
public class KeywordSearch {

    private InvertedIndex index;
    private TextProcessor processor;

    public KeywordSearch(InvertedIndex index) {
        this.index = index;
        this.processor = new TextProcessor();
    }

    public ArrayList<WebDocument> search(
            String query,
            ArrayList<WebDocument> documents) {

        ArrayList<WebDocument> results = new ArrayList<>();

        if (query == null
                || query.trim().isEmpty()
                || documents == null
                || documents.isEmpty()) {
            return results;
        }

        // Tokenize multi-word query into normalized keywords
        String[] queryWords = processor.process(query);

        if (queryWords.length == 0) {
            return results;
        }

        // DSA: Frequency map to count how many query terms each document matches
        HashMap<Integer, Integer> matchCounts = new HashMap<>();

        for (String word : queryWords) {
            // DSA: Inverted Index lookup for this specific word
            ArrayList<Integer> ids = index.search(word);

            for (Integer id : ids) {
                if (id >= 0 && id < documents.size()) {
                    matchCounts.put(id, matchCounts.getOrDefault(id, 0) + 1);
                }
            }
        }

        // Collect matching document IDs
        ArrayList<Integer> matchedIds = new ArrayList<>(matchCounts.keySet());

        // DSA: Bubble Sort to rank documents matching MORE query keywords first
        for (int i = 0; i < matchedIds.size() - 1; i++) {
            for (int j = 0; j < matchedIds.size() - i - 1; j++) {
                int countA = matchCounts.get(matchedIds.get(j));
                int countB = matchCounts.get(matchedIds.get(j + 1));

                if (countA < countB) {
                    int temp = matchedIds.get(j);
                    matchedIds.set(j, matchedIds.get(j + 1));
                    matchedIds.set(j + 1, temp);
                }
            }
        }

        for (Integer id : matchedIds) {
            results.add(documents.get(id));
        }

        return results;
    }
}