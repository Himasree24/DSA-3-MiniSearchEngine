package com.searchengine;

import java.util.ArrayList;

public class CrawlerTest {

    public static void main(String[] args) {

        System.out.println(
                "Starting crawler..."
        );

        WebCrawler crawler =
                new WebCrawler(20, 2);

        String startUrl =
                "https://en.wikipedia.org/wiki/Java_(programming_language)";

        ArrayList<WebDocument> documents =
                crawler.crawl(startUrl);

        System.out.println();

        System.out.println(
                "Pages crawled: "
                        + documents.size()
        );

        System.out.println();

        for (WebDocument document :
                documents) {

            System.out.println(
                    "Title: "
                            + document.getTitle()
            );

            System.out.println(
                    "URL: "
                            + document.getUrl()
            );

            String text =
                    document.getText();

            if (text.length() > 150) {

                text =
                        text.substring(
                                0,
                                150
                        ) + "...";
            }

            System.out.println(
                    "Text: " + text
            );

            System.out.println(
                    "-----------------------------------"
            );
        }
    }
}