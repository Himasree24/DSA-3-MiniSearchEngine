const searchInput = document.getElementById("searchInput");
const searchButton = document.getElementById("searchButton");
const resultsContainer = document.getElementById("results");
const status = document.getElementById("status");

const typeButtons = document.querySelectorAll(".type-button");

let selectedType = "keyword";

// =================================
// SELECT SEARCH TYPE
// =================================

typeButtons.forEach(button => {

    button.addEventListener("click", () => {

        typeButtons.forEach(b => {
            b.classList.remove("active");
        });

        button.classList.add("active");

        selectedType = button.dataset.type;
    });

});


// =================================
// SEARCH BUTTON
// =================================

searchButton.addEventListener("click", performSearch);


// =================================
// ENTER KEY
// =================================

searchInput.addEventListener("keydown", event => {

    if (event.key === "Enter") {
        performSearch();
    }

});


// =================================
// SEARCH
// =================================

async function performSearch() {

    const query = searchInput.value.trim();

    if (!query) {

        status.textContent =
            "Please enter something to search.";

        resultsContainer.innerHTML = "";

        return;
    }


    status.textContent = "Searching...";

    resultsContainer.innerHTML = "";

    searchButton.disabled = true;


    try {

        const url =
            "http://localhost:8080/search"
            + "?query="
            + encodeURIComponent(query)
            + "&type="
            + encodeURIComponent(selectedType);


        const response = await fetch(url);


        if (!response.ok) {

            throw new Error(
                "Server returned " + response.status
            );

        }


        const data = await response.json();


        displayResults(data);


    } catch (error) {

        console.error(error);

        status.textContent =
            "Could not connect to the search server.";


        resultsContainer.innerHTML = `
            <div class="error">

                <h3>Search server unavailable</h3>

                <p>
                    Make sure SearchServer.java
                    is running on port 8080.
                </p>

            </div>
        `;

    } finally {

        searchButton.disabled = false;

    }

}


// =================================
// DISPLAY RESULTS
// =================================

function displayResults(data) {

    const results = data.results || [];


    if (results.length === 0) {

        status.textContent =
            `No results found for "${data.query}".`;


        resultsContainer.innerHTML = `
            <div class="no-results">

                <div class="big-icon">
                    🔍
                </div>

                <h2>
                    No results found
                </h2>

                <p>
                    Try another search term.
                </p>

            </div>
        `;

        return;
    }


    status.textContent =
        `${data.count} results found`;


    resultsContainer.innerHTML = "";


    results.forEach((result, index) => {

        const card =
            document.createElement("article");


        card.className = "result-card";


        const number = index + 1;


        const score =
            Number(result.score);


        card.innerHTML = `

            <div class="result-number">
                ${number}
            </div>


            <div class="result-content">

                <a
                    class="result-title"
                    href="${escapeAttribute(result.url)}"
                    target="_blank">

                    ${escapeHtml(result.title)}

                </a>


                <div class="result-url">

                    ${escapeHtml(result.url)}

                </div>


                <p class="snippet">

                    ${escapeHtml(result.snippet)}

                </p>


                <div class="result-meta">

                    <span>

                        Relevance:
                        ${(score * 100).toFixed(0)}%

                    </span>


                    <span>

                        ${escapeHtml(data.type)}

                    </span>

                </div>

            </div>

        `;


        resultsContainer.appendChild(card);

    });

}


// =================================
// HTML ESCAPE
// =================================

function escapeHtml(text) {

    if (text === undefined || text === null) {
        return "";
    }


    return String(text)

        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


// =================================
// ATTRIBUTE ESCAPE
// =================================

function escapeAttribute(text) {

    return escapeHtml(text);

}