package com.searchengine;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * SearchServer hosts the HTTP API (/search) for the Mini Search Engine.
 *
 * Architecture Flow:
 * 1. Frontend query -> SearchServer receives query & selected algorithm type.
 * 2. WikipediaSearcher dynamically searches Wikipedia Search API for ~10 candidate URLs.
 * 3. WebCrawler (Queue/BFS, HashSet duplicate filter) fetches HTML and builds WebDocument objects.
 * 4. SearchEngine indexes candidate WebDocuments.
 * 5. Selected DSA algorithm (InvertedIndex, EditDistance DP, TF-IDF, Cosine Sim) filters/ranks documents.
 * 6. Returns filtered/ranked results with snippets and scores in JSON to the frontend.
 */
public class SearchServer {

    // In-memory cache: caches downloaded WebDocuments by topic
    // Avoids redundant web requests when switching between algorithm tabs for the same topic
    private static final Map<String, ArrayList<WebDocument>> documentCache =
            new ConcurrentHashMap<>();

    public static void main(String[] args) throws Exception {

        System.out.println("Starting Mini Search Engine...");

        HttpServer server =
                HttpServer.create(
                        new InetSocketAddress(8080),
                        0
                );

        server.createContext(
                "/",
                SearchServer::handleRoot
        );

        server.createContext(
                "/search",
                SearchServer::handleSearch
        );

        server.setExecutor(null);
        server.start();

        System.out.println();
        System.out.println("==========================================");
        System.out.println(" Mini Search Engine Server Running");
        System.out.println(" URL: http://localhost:8080");
        System.out.println(" Ready for dynamic web document retrieval!");
        System.out.println("==========================================");
    }

    private static void handleRoot(
            HttpExchange exchange)
            throws IOException {

        addCors(exchange);

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            exchange.close();
            return;
        }

        String response = "Mini Search Engine API is running! Use /search?query=...&type=...";
        sendResponse(exchange, response, "text/plain");
    }

    private static void handleSearch(
            HttpExchange exchange)
            throws IOException {

        addCors(exchange);

        // Handle CORS preflight
        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            exchange.close();
            return;
        }

        String query = "";
        String type = "keyword";

        String rawQuery = exchange.getRequestURI().getRawQuery();

        if (rawQuery != null) {
            String[] parameters = rawQuery.split("&");

            for (String parameter : parameters) {
                String[] pair = parameter.split("=", 2);
                if (pair.length != 2) {
                    continue;
                }

                String key = URLDecoder.decode(pair[0], StandardCharsets.UTF_8);
                String value = URLDecoder.decode(pair[1], StandardCharsets.UTF_8);

                if ("query".equalsIgnoreCase(key)) {
                    query = value;
                } else if ("type".equalsIgnoreCase(key)) {
                    type = value;
                }
            }
        }

        query = query.trim();

        if (query.isEmpty()) {
            sendResponse(exchange, createEmptyResultsJson("", type), "application/json");
            return;
        }

        System.out.println("\n--- Received search request ---");
        System.out.println("Query: [" + query + "] | Algorithm: [" + type + "]");

        // ========================================================
        // DYNAMIC DOCUMENT RETRIEVAL
        // Retrieve candidate documents for any query topic
        // ========================================================
        String cacheKey = query.toLowerCase();
        ArrayList<WebDocument> candidateDocuments = documentCache.get(cacheKey);

        if (candidateDocuments == null || candidateDocuments.isEmpty()) {
            System.out.println("Querying Wikipedia Search API for candidate URLs...");

            // 1. Get ~10 candidate article URLs from Wikipedia Search API
            WikipediaSearcher searcher = new WikipediaSearcher();
            ArrayList<String> candidateUrls = searcher.search(query, 10);

            if (candidateUrls.isEmpty()) {
                System.out.println("No candidate Wikipedia pages found for: " + query);
                sendResponse(exchange, createEmptyResultsJson(query, type), "application/json");
                return;
            }

            System.out.println("Found " + candidateUrls.size() + " candidate URLs. Downloading pages...");

            // 2. Fetch pages using WebCrawler (BFS Queue, depth 0 to avoid drifting)
            WebCrawler crawler = new WebCrawler(10, 0);
            candidateDocuments = crawler.crawl(candidateUrls);

            if (candidateDocuments.isEmpty()) {
                System.out.println("Could not extract documents from URLs.");
                sendResponse(exchange, createEmptyResultsJson(query, type), "application/json");
                return;
            }

            // Cache candidate documents for rapid switching across search modes
            documentCache.put(cacheKey, candidateDocuments);
        } else {
            System.out.println("Using cached candidate documents (" + candidateDocuments.size() + " pages).");
        }

        // ========================================================
        // PASS DOCUMENTS TO OUR OWN SEARCH ENGINE & APPLY DSA
        // ========================================================
        SearchEngine searchEngine = new SearchEngine(candidateDocuments);

        // Apply selected DSA algorithm (InvertedIndex, EditDistance, TF-IDF, Cosine Sim)
        ArrayList<WebDocument> results = searchEngine.search(query, type);

        System.out.println("Algorithm [" + type + "] matched " + results.size() + " document(s).");

        // Build JSON response
        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"query\":\"").append(escapeJson(query)).append("\",");
        json.append("\"type\":\"").append(escapeJson(type)).append("\",");
        json.append("\"count\":").append(results.size()).append(",");
        json.append("\"results\":[");

        for (int i = 0; i < results.size(); i++) {
            WebDocument document = results.get(i);
            double score = searchEngine.getScore(query, type, document);

            json.append("{");
            json.append("\"title\":\"").append(escapeJson(document.getTitle())).append("\",");
            json.append("\"url\":\"").append(escapeJson(document.getUrl())).append("\",");
            json.append("\"snippet\":\"").append(escapeJson(createSnippet(document, query))).append("\",");
            json.append("\"score\":").append(String.format(java.util.Locale.US, "%.4f", score));
            json.append("}");

            if (i < results.size() - 1) {
                json.append(",");
            }
        }

        json.append("]");
        json.append("}");

        sendResponse(exchange, json.toString(), "application/json");
    }

    private static String createEmptyResultsJson(String query, String type) {
        return "{\"query\":\"" + escapeJson(query) + "\",\"type\":\"" + escapeJson(type)
                + "\",\"count\":0,\"results\":[]}";
    }

    private static String createSnippet(
            WebDocument document,
            String query) {

        String text = document.getText();
        if (text == null) {
            return "";
        }

        text = text.replaceAll("\\s+", " ").trim();

        if (text.length() <= 250) {
            return text;
        }

        String lower = text.toLowerCase();
        String q = query.toLowerCase();

        // 1. Try finding full query phrase
        int position = lower.indexOf(q);

        if (position >= 0) {
            int start = Math.max(0, position - 60);
            int end = Math.min(text.length(), position + query.length() + 180);
            return (start > 0 ? "... " : "") + text.substring(start, end) + (end < text.length() ? "..." : "");
        }

        // 2. Try finding individual words from query
        TextProcessor processor = new TextProcessor();
        String[] words = processor.process(query);

        for (String w : words) {
            if (w.length() > 2) {
                int pos = lower.indexOf(w);
                if (pos >= 0) {
                    int start = Math.max(0, pos - 60);
                    int end = Math.min(text.length(), pos + 180);
                    return (start > 0 ? "... " : "") + text.substring(start, end) + (end < text.length() ? "..." : "");
                }
            }
        }

        return text.substring(0, 250) + "...";
    }

    private static String escapeJson(String text) {
        if (text == null) {
            return "";
        }

        return text
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private static void addCors(HttpExchange exchange) {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");
    }

    private static void sendResponse(
            HttpExchange exchange,
            String response,
            String contentType)
            throws IOException {

        byte[] bytes = response.getBytes(StandardCharsets.UTF_8);

        exchange.getResponseHeaders().set(
                "Content-Type",
                contentType + "; charset=UTF-8"
        );

        exchange.sendResponseHeaders(200, bytes.length);

        try (OutputStream output = exchange.getResponseBody()) {
            output.write(bytes);
        }
    }
}