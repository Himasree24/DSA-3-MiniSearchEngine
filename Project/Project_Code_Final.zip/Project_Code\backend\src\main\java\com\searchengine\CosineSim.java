package com.searchengine;

public class CosineSim {

    public double calculate(
            int[] vectorA,
            int[] vectorB) {

        if (vectorA == null
                || vectorB == null
                || vectorA.length != vectorB.length) {

            return 0.0;
        }

        double dotProduct = 0.0;
        double magnitudeA = 0.0;
        double magnitudeB = 0.0;

        for (int i = 0;
             i < vectorA.length;
             i++) {

            dotProduct +=
                    vectorA[i] * vectorB[i];

            magnitudeA +=
                    vectorA[i] * vectorA[i];

            magnitudeB +=
                    vectorB[i] * vectorB[i];
        }

        if (magnitudeA == 0
                || magnitudeB == 0) {

            return 0.0;
        }

        return dotProduct /
                (
                    Math.sqrt(magnitudeA)
                    * Math.sqrt(magnitudeB)
                );
    }
}