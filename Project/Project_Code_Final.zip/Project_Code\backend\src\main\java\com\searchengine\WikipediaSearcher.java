package com.searchengine;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Dynamically queries Wikipedia Search API to retrieve candidate article URLs
 * for any user query topic.
 *
 * NOTE: The Wikipedia API is ONLY used to retrieve candidate URLs.
 * Documents are fetched and processed by our own DSA algorithms
 * (InvertedIndex, EditDistance, TF-IDF, Cosine Similarity, etc.).
 */
public class WikipediaSearcher {

    private HttpClient client;

    public WikipediaSearcher() {
        this.client = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .connectTimeout(Duration.ofSeconds(6))
                .build();
    }

    /**
     * Search Wikipedia for candidate article URLs for a given topic.
     *
     * @param query The user's search query topic.
     * @param limit Target number of candidate URLs (e.g. 10 to 15).
     * @return List of Wikipedia article URLs.
     */
    public ArrayList<String> search(String query, int limit) {
        ArrayList<String> candidateUrls = new ArrayList<>();
        Set<String> seen = new HashSet<>();

        if (query == null || query.trim().isEmpty()) {
            return candidateUrls;
        }

        query = query.trim();

        try {
            String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8);

            // ========================================================
            // 1. Wikipedia OpenSearch API (fast prefix & typo search)
            // ========================================================
            String opensearchUrl = "https://en.wikipedia.org/w/api.php?action=opensearch&search="
                    + encodedQuery + "&limit=" + limit + "&namespace=0&format=json";

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(opensearchUrl))
                    .header("User-Agent", "MiniSearchEngine/1.0 (DSA College Project; student@college.edu)")
                    .GET()
                    .timeout(Duration.ofSeconds(6))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                String body = response.body().replace("\\/", "/");
                // OpenSearch returns URLs in the 4th JSON element
                Pattern urlPattern = Pattern.compile("https://en\\.wikipedia\\.org/wiki/[^\"\\\\\\s]+");
                Matcher matcher = urlPattern.matcher(body);

                while (matcher.find() && candidateUrls.size() < limit) {
                    String url = matcher.group();
                    if (!seen.contains(url)) {
                        seen.add(url);
                        candidateUrls.add(url);
                    }
                }
            }

            // ========================================================
            // 2. Fallback / Supplement: MediaWiki Query Search API
            // Used if OpenSearch returned fewer than desired results
            // ========================================================
            if (candidateUrls.size() < limit) {
                String searchApiUrl = "https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch="
                        + encodedQuery + "&srlimit=" + limit + "&format=json";

                HttpRequest searchReq = HttpRequest.newBuilder()
                        .uri(URI.create(searchApiUrl))
                        .header("User-Agent", "MiniSearchEngine/1.0 (DSA College Project; student@college.edu)")
                        .GET()
                        .timeout(Duration.ofSeconds(6))
                        .build();

                HttpResponse<String> searchResp = client.send(searchReq, HttpResponse.BodyHandlers.ofString());

                if (searchResp.statusCode() == 200) {
                    String searchBody = searchResp.body();

                    // If zero results, check for suggestion (spell correction from Wikipedia)
                    if (candidateUrls.isEmpty()) {
                        Pattern sugPattern = Pattern.compile("\"suggestion\"\\s*:\\s*\"([^\"]+)\"");
                        Matcher sugMatcher = sugPattern.matcher(searchBody);
                        if (sugMatcher.find()) {
                            String suggestion = sugMatcher.group(1);
                            return search(suggestion, limit);
                        }
                    }

                    Pattern titlePattern = Pattern.compile("\"title\"\\s*:\\s*\"([^\"]+)\"");
                    Matcher titleMatcher = titlePattern.matcher(searchBody);

                    while (titleMatcher.find() && candidateUrls.size() < limit) {
                        String title = titleMatcher.group(1).replace(" ", "_");
                        String url = "https://en.wikipedia.org/wiki/" + title;
                        if (!seen.contains(url)) {
                            seen.add(url);
                            candidateUrls.add(url);
                        }
                    }
                }
            }

        } catch (Exception e) {
            System.err.println("WikipediaSearcher error: " + e.getMessage());
        }

        return candidateUrls;
    }

    /**
     * Search with default limit of 10 candidate URLs.
     */
    public ArrayList<String> search(String query) {
        return search(query, 10);
    }
}
