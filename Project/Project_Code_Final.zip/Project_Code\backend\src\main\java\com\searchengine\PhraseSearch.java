package com.searchengine;

import java.util.ArrayList;

/**
 * PhraseSearch searches for exact contiguous phrase occurrences within documents.
 *
 * DSA Concepts Used:
 * - Substring searching: Verifies whether the exact sequence of query words occurs
 *   contiguously in the document title or text.
 */
public class PhraseSearch {

    public PhraseSearch() {
    }

    public ArrayList<WebDocument> search(
            String phrase,
            ArrayList<WebDocument> documents) {

        ArrayList<WebDocument> results = new ArrayList<>();

        if (phrase == null
                || phrase.trim().isEmpty()
                || documents == null
                || documents.isEmpty()) {
            return results;
        }

        // Normalize phrase whitespace and case
        String normalizedPhrase = phrase.replaceAll("\\s+", " ").toLowerCase().trim();

        for (WebDocument document : documents) {
            String text = document.getText();
            String title = document.getTitle();

            boolean matched = false;

            if (title != null && title.toLowerCase().contains(normalizedPhrase)) {
                matched = true;
            } else if (text != null && text.toLowerCase().contains(normalizedPhrase)) {
                matched = true;
            }

            if (matched) {
                results.add(document);
            }
        }

        return results;
    }
}