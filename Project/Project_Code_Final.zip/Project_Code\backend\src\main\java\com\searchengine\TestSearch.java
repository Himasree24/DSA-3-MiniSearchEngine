package com.searchengine;

import java.util.ArrayList;

public class TestSearch {

    public static void main(String[] args) {

        ArrayList<WebDocument> documents =
                new ArrayList<>();

        documents.add(
                new WebDocument(
                        "Java",
                        "Java is a programming language.",
                        "https://example.com/java"
                )
        );

        documents.add(
                new WebDocument(
                        "Python",
                        "Python is a programming language.",
                        "https://example.com/python"
                )
        );

        documents.add(
                new WebDocument(
                        "Web Development",
                        "Web development uses Java and JavaScript.",
                        "https://example.com/web"
                )
        );

        InvertedIndex index =
                new InvertedIndex();

        TextProcessor processor =
                new TextProcessor();

        for (int i = 0;
             i < documents.size();
             i++) {

            String[] words =
                    processor.process(
                            documents.get(i).getText()
                    );

            for (String word : words) {

                index.addWord(
                        word,
                        i
                );
            }
        }

        KeywordSearch keywordSearch =
                new KeywordSearch(index);

        ArrayList<WebDocument> results =
                keywordSearch.search(
                        "java",
                        documents
                );

        System.out.println(
                "Search results for: java"
        );

        for (WebDocument document :
                results) {

            System.out.println(
                    document.getTitle()
            );
        }
    }
}