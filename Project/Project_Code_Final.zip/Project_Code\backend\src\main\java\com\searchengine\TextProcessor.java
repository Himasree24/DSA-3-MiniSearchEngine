package com.searchengine;

public class TextProcessor {

    public String[] process(String text) {

        if (text == null) {
            return new String[0];
        }

        String cleaned =
                text.toLowerCase()
                    .replaceAll("[^a-z0-9 ]", " ")
                    .replaceAll("\\s+", " ")
                    .trim();

        if (cleaned.isEmpty()) {
            return new String[0];
        }

        return cleaned.split(" ");
    }
}