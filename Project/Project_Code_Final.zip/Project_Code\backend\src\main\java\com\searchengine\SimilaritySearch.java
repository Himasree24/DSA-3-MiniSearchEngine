package com.searchengine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * SimilaritySearch scores documents by Vector Space Model representation
 * and Cosine Similarity.
 *
 * DSA Concepts Used:
 * - Vector Space Model: Represents queries and documents as word-frequency vectors in V-dimensional space.
 * - Cosine Similarity: Calculates the normalized dot product of two vectors (A · B) / (||A|| * ||B||).
 * - HashMap / LinkedHashSet: Fast O(1) vocabulary indexing and vector generation.
 * - Bubble Sort: Orders matching documents by cosine similarity descending.
 */
public class SimilaritySearch {

    private TextProcessor processor;
    private CosineSim cosine;

    public SimilaritySearch() {
        this.processor = new TextProcessor();
        this.cosine = new CosineSim();
    }

    public ArrayList<WebDocument> search(
            String query,
            ArrayList<WebDocument> documents) {

        ArrayList<WebDocument> results = new ArrayList<>();

        if (query == null
                || query.trim().isEmpty()
                || documents == null
                || documents.isEmpty()) {
            return results;
        }

        String[] queryWords = processor.process(query);
        if (queryWords.length == 0) {
            return results;
        }

        // Preprocess all document word arrays
        ArrayList<String[]> docWordsList = new ArrayList<>();
        for (WebDocument doc : documents) {
            docWordsList.add(processor.process(doc.getText()));
        }

        // DSA: Build unified vocabulary using LinkedHashSet for O(1) uniqueness
        Set<String> vocabSet = new LinkedHashSet<>();
        for (String word : queryWords) {
            vocabSet.add(word);
        }
        for (String[] docWords : docWordsList) {
            for (String word : docWords) {
                vocabSet.add(word);
            }
        }

        ArrayList<String> vocabulary = new ArrayList<>(vocabSet);
        HashMap<String, Integer> wordIndexMap = new HashMap<>();
        for (int i = 0; i < vocabulary.size(); i++) {
            wordIndexMap.put(vocabulary.get(i), i);
        }

        int vocabSize = vocabulary.size();

        // Create query vector
        int[] queryVector = createVector(queryWords, wordIndexMap, vocabSize);

        ArrayList<WebDocument> matching = new ArrayList<>();
        ArrayList<Double> scores = new ArrayList<>();

        // Calculate cosine similarity for each document vector
        for (int i = 0; i < documents.size(); i++) {
            int[] documentVector = createVector(docWordsList.get(i), wordIndexMap, vocabSize);
            double score = cosine.calculate(queryVector, documentVector);

            if (score > 0) {
                matching.add(documents.get(i));
                scores.add(score);
            }
        }

        // DSA: Bubble Sort by highest similarity first
        for (int i = 0; i < scores.size() - 1; i++) {
            for (int j = 0; j < scores.size() - i - 1; j++) {
                if (scores.get(j) < scores.get(j + 1)) {
                    double tempScore = scores.get(j);
                    scores.set(j, scores.get(j + 1));
                    scores.set(j + 1, tempScore);

                    WebDocument temp = matching.get(j);
                    matching.set(j, matching.get(j + 1));
                    matching.set(j + 1, temp);
                }
            }
        }

        results.addAll(matching);
        return results;
    }

    private int[] createVector(
            String[] words,
            HashMap<String, Integer> wordIndexMap,
            int vocabSize) {

        int[] vector = new int[vocabSize];
        for (String word : words) {
            Integer position = wordIndexMap.get(word);
            if (position != null) {
                vector[position]++;
            }
        }
        return vector;
    }

    public double getScore(
            String query,
            WebDocument document) {

        if (query == null || document == null) {
            return 0.0;
        }

        String[] queryWords = processor.process(query);
        String[] documentWords = processor.process(document.getText());

        if (queryWords.length == 0 || documentWords.length == 0) {
            return 0.0;
        }

        Set<String> vocabSet = new LinkedHashSet<>();
        for (String word : queryWords) {
            vocabSet.add(word);
        }
        for (String word : documentWords) {
            vocabSet.add(word);
        }

        ArrayList<String> vocabulary = new ArrayList<>(vocabSet);
        HashMap<String, Integer> wordIndexMap = new HashMap<>();
        for (int i = 0; i < vocabulary.size(); i++) {
            wordIndexMap.put(vocabulary.get(i), i);
        }

        int[] vectorA = createVector(queryWords, wordIndexMap, vocabulary.size());
        int[] vectorB = createVector(documentWords, wordIndexMap, vocabulary.size());

        return cosine.calculate(vectorA, vectorB);
    }
}