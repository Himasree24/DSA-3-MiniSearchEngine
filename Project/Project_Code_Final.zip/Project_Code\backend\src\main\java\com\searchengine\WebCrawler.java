package com.searchengine;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * WebCrawler retrieves web pages using a Breadth-First Search (BFS) strategy.
 *
 * DSA Concepts Used:
 * - Queue (ArrayDeque): Implements BFS frontier to process URLs in FIFO order.
 * - HashSet: Ensures O(1) duplicate URL detection and avoids infinite crawl cycles.
 * - Tree/Graph Traversal: Crawls page hierarchy up to maxDepth.
 */
public class WebCrawler {

    private int maxPages;
    private int maxDepth;
    private HttpClient client;
    private Set<String> visited;
    private ArrayList<WebDocument> documents;

    public WebCrawler(int maxPages, int maxDepth) {
        this.maxPages = maxPages;
        this.maxDepth = maxDepth;

        this.client = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .connectTimeout(Duration.ofSeconds(5))
                .build();

        // HashSet for O(1) duplicate URL prevention
        this.visited = new HashSet<>();
        this.documents = new ArrayList<>();
    }

    /**
     * Single start URL crawl (for backward compatibility / testing).
     */
    public ArrayList<WebDocument> crawl(String startUrl) {
        ArrayList<String> urls = new ArrayList<>();
        if (startUrl != null && !startUrl.trim().isEmpty()) {
            urls.add(startUrl.trim());
        }
        return crawl(urls);
    }

    /**
     * Crawls starting from multiple candidate URLs.
     * Uses Queue (BFS) to visit pages level by level.
     * For normal searching, maxDepth=0 so candidate pages are fetched directly
     * without branching into unrelated links.
     */
    public ArrayList<WebDocument> crawl(List<String> startUrls) {
        // DSA: Queue for Breadth-First Search (BFS)
        Queue<CrawlItem> queue = new ArrayDeque<>();

        if (startUrls != null) {
            for (String url : startUrls) {
                if (url != null && !url.trim().isEmpty() && !visited.contains(url.trim())) {
                    queue.add(new CrawlItem(url.trim(), 0));
                }
            }
        }

        System.out.println("Crawling candidate pages (Queue size: " + queue.size() + ", maxPages: " + maxPages + ")...");

        while (!queue.isEmpty() && documents.size() < maxPages) {
            CrawlItem item = queue.poll();
            String url = item.url;
            int depth = item.depth;

            // Skip URLs already visited (DSA: HashSet lookup O(1))
            if (visited.contains(url)) {
                continue;
            }

            // Skip URLs that are not valid Wikipedia article links
            if (!isValidLink(url)) {
                continue;
            }

            // Skip if depth exceeds allowed max depth
            if (depth > maxDepth) {
                continue;
            }

            visited.add(url);

            try {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("User-Agent", "MiniSearchEngine/1.0 (DSA College Project; student@college.edu)")
                        .GET()
                        .timeout(Duration.ofSeconds(5))
                        .build();

                HttpResponse<String> response = client.send(
                        request,
                        HttpResponse.BodyHandlers.ofString()
                );

                if (response.statusCode() != 200) {
                    continue;
                }

                String html = response.body();

                // Ensure content is HTML
                String contentType = response.headers()
                        .firstValue("Content-Type")
                        .orElse("");

                if (!contentType.toLowerCase().contains("text/html")) {
                    continue;
                }

                // Extract title and text
                String title = extractTitle(html);
                String text = extractText(html);

                if (title.isEmpty()) {
                    title = "Untitled";
                }

                if (text.isEmpty()) {
                    continue;
                }

                WebDocument document = new WebDocument(title, text, url);
                documents.add(document);

                System.out.println("  Indexed: " + title);

                // Stop if target document count reached
                if (documents.size() >= maxPages) {
                    break;
                }

                // DSA BFS link expansion: only explore adjacent links if depth < maxDepth
                if (depth < maxDepth) {
                    ArrayList<String> links = extractLinks(html, url);
                    for (String link : links) {
                        if (!visited.contains(link) && isValidLink(link)) {
                            queue.add(new CrawlItem(link, depth + 1));
                        }
                    }
                }

            } catch (Exception e) {
                System.out.println("  Skipping " + url + " (" + e.getMessage() + ")");
            }
        }

        System.out.println("Crawling completed. Total documents indexed: " + documents.size());
        return documents;
    }

    // ==========================================
    // CHECK WHETHER URL IS A VALID WIKIPEDIA ARTICLE
    // ==========================================
    private boolean isValidLink(String url) {
        if (url == null || url.isEmpty()) {
            return false;
        }

        // Only Wikipedia article pages
        if (!url.startsWith("https://en.wikipedia.org/wiki/")) {
            return false;
        }

        // Exclude non-article / metadata pages
        if (url.contains("#")
                || url.contains("?")
                || url.contains("/wiki/Special:")
                || url.contains("/wiki/File:")
                || url.contains("/wiki/Category:")
                || url.contains("/wiki/Help:")
                || url.contains("/wiki/Template:")
                || url.contains("/wiki/User:")
                || url.contains("/wiki/Talk:")
                || url.contains("/wiki/Portal:")) {
            return false;
        }

        return true;
    }

    // ==========================================
    // EXTRACT TITLE
    // ==========================================
    private String extractTitle(String html) {
        Pattern pattern = Pattern.compile(
                "<title[^>]*>(.*?)</title>",
                Pattern.CASE_INSENSITIVE | Pattern.DOTALL
        );

        Matcher matcher = pattern.matcher(html);
        if (matcher.find()) {
            String title = matcher.group(1);
            title = title.replaceAll("\\s+", " ").trim();
            return decodeHtml(title);
        }

        return "";
    }

    // ==========================================
    // EXTRACT READABLE TEXT
    // ==========================================
    private String extractText(String html) {
        String text = html;

        // Remove scripts, styles, noscript, SVG, comments
        text = text.replaceAll("(?is)<script.*?>.*?</script>", " ");
        text = text.replaceAll("(?is)<style.*?>.*?</style>", " ");
        text = text.replaceAll("(?is)<noscript.*?>.*?</noscript>", " ");
        text = text.replaceAll("(?is)<svg.*?>.*?</svg>", " ");
        text = text.replaceAll("(?s)<!--.*?-->", " ");

        // Remove all HTML tags
        text = text.replaceAll("<[^>]*>", " ");

        // Decode common HTML entities
        text = decodeHtml(text);

        // Normalize whitespace
        text = text.replaceAll("\\s+", " ").trim();

        return text;
    }

    // ==========================================
    // EXTRACT LINKS
    // ==========================================
    private ArrayList<String> extractLinks(String html, String currentUrl) {
        ArrayList<String> links = new ArrayList<>();

        Pattern pattern = Pattern.compile(
                "<a[^>]+href\\s*=\\s*[\"']([^\"']+)[\"']",
                Pattern.CASE_INSENSITIVE
        );

        Matcher matcher = pattern.matcher(html);

        while (matcher.find()) {
            String link = matcher.group(1).trim();

            try {
                URI current = URI.create(currentUrl);
                URI absolute = current.resolve(link);
                String fullUrl = absolute.toString();

                int hash = fullUrl.indexOf("#");
                if (hash != -1) {
                    fullUrl = fullUrl.substring(0, hash);
                }

                fullUrl = decodeHtml(fullUrl);

                if (isValidLink(fullUrl) && !links.contains(fullUrl)) {
                    links.add(fullUrl);
                }
            } catch (Exception e) {
                // Ignore malformed links
            }
        }

        return links;
    }

    // ==========================================
    // DECODE COMMON HTML ENTITIES
    // ==========================================
    private String decodeHtml(String text) {
        return text
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&#39;", "'")
                .replace("&nbsp;", " ");
    }

    // ==========================================
    // CRAWL ITEM FOR BFS QUEUE
    // ==========================================
    private static class CrawlItem {
        String url;
        int depth;

        CrawlItem(String url, int depth) {
            this.url = url;
            this.depth = depth;
        }
    }
}