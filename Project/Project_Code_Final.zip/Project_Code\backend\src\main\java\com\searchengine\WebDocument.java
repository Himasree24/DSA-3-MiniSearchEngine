package com.searchengine;

public class WebDocument {

    private String title;
    private String text;
    private String url;

    public WebDocument(
            String title,
            String text,
            String url) {

        this.title = title;
        this.text = text;
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public String getUrl() {
        return url;
    }
}