package com.searchengine;

/**
 * TFIDF calculates Term Frequency - Inverse Document Frequency weights.
 *
 * DSA Concepts Used:
 * - Term Frequency (TF): term occurrences / total words in document.
 * - Inverse Document Frequency (IDF): log(totalDocuments / documentsContainingTerm) + 1.0.
 *   The +1.0 smoothing term is the standard Information Retrieval practice to prevent
 *   valid search terms that appear across all candidate documents from vanishing to weight 0.
 */
public class TFIDF {

    public double calculateTF(
            int termCount,
            int totalWords) {

        if (totalWords == 0) {
            return 0.0;
        }

        return (double) termCount
                / totalWords;
    }

    public double calculateIDF(
            int totalDocuments,
            int documentsContainingTerm) {

        if (documentsContainingTerm == 0 || totalDocuments == 0) {
            return 0.0;
        }

        // Standard smoothed IDF: ensures terms appearing across candidate set retain positive weight
        return Math.log(
                (double) totalDocuments
                        / documentsContainingTerm
        ) + 1.0;
    }

    public double calculateTFIDF(
            double tf,
            double idf) {

        return tf * idf;
    }
}