package com.searchengine;

import java.util.ArrayList;

public class DocumentSimilarity {

    private TextProcessor processor;
    private CosineSim cosine;

    public DocumentSimilarity() {

        processor =
                new TextProcessor();

        cosine =
                new CosineSim();
    }

    public double compare(
            WebDocument document1,
            WebDocument document2) {

        String[] words1 =
                processor.process(
                        document1.getText()
                );

        String[] words2 =
                processor.process(
                        document2.getText()
                );

        ArrayList<String> vocabulary =
                new ArrayList<>();

        for (String word : words1) {

            if (!vocabulary.contains(word)) {
                vocabulary.add(word);
            }
        }

        for (String word : words2) {

            if (!vocabulary.contains(word)) {
                vocabulary.add(word);
            }
        }

        int[] vector1 =
                createVector(
                        words1,
                        vocabulary
                );

        int[] vector2 =
                createVector(
                        words2,
                        vocabulary
                );

        return cosine.calculate(
                vector1,
                vector2
        );
    }

    private int[] createVector(
            String[] words,
            ArrayList<String> vocabulary) {

        int[] vector =
                new int[vocabulary.size()];

        for (String word : words) {

            int position =
                    vocabulary.indexOf(word);

            if (position >= 0) {
                vector[position]++;
            }
        }

        return vector;
    }
}