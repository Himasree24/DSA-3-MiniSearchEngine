package com.searchengine;

import java.util.ArrayList;

/**
 * SearchEngine coordinates the search algorithms across dynamically retrieved WebDocument objects.
 *
 * DSA Concepts Used:
 * - Inverted Index Construction: Maps terms to document indices.
 * - Dispatches queries to selected DSA algorithms (Keyword with Inverted Index,
 *   Exact Phrase Matching, Fuzzy Search with Edit Distance DP, TF-IDF Ranker,
 *   and Cosine Vector Similarity).
 */
public class SearchEngine {

    private ArrayList<WebDocument> documents;
    private InvertedIndex index;

    private KeywordSearch keywordSearch;
    private PhraseSearch phraseSearch;
    private FuzzySearch fuzzySearch;
    private Ranker ranker;
    private SimilaritySearch similaritySearch;

    public SearchEngine(ArrayList<WebDocument> documents) {
        this.documents = (documents != null) ? documents : new ArrayList<>();
        this.index = new InvertedIndex();

        TextProcessor processor = new TextProcessor();

        // Build inverted index (DSA: HashMap<String, ArrayList<Integer>>)
        for (int i = 0; i < this.documents.size(); i++) {
            String[] words = processor.process(this.documents.get(i).getText());
            for (String word : words) {
                index.addWord(word, i);
            }
        }

        this.keywordSearch = new KeywordSearch(index);
        this.phraseSearch = new PhraseSearch();
        this.fuzzySearch = new FuzzySearch();
        this.ranker = new Ranker();
        this.similaritySearch = new SimilaritySearch();
    }

    public ArrayList<WebDocument> search(
            String query,
            String type) {

        if (query == null
                || query.trim().isEmpty()
                || documents.isEmpty()) {
            return new ArrayList<>();
        }

        if (type == null) {
            type = "keyword";
        }

        type = type.toLowerCase().trim();

        switch (type) {
            case "keyword":
                return keywordSearch.search(query, documents);

            case "phrase":
                return phraseSearch.search(query, documents);

            case "fuzzy":
                return fuzzySearch.search(query, documents);

            case "rank":
                return ranker.rank(query, documents);

            case "similarity":
                return similaritySearch.search(query, documents);

            default:
                return keywordSearch.search(query, documents);
        }
    }

    public double getScore(
            String query,
            String type,
            WebDocument document) {

        if ("rank".equalsIgnoreCase(type)) {
            return ranker.getScore(
                    query,
                    document,
                    documents
            );
        }

        if ("similarity".equalsIgnoreCase(type)) {
            return similaritySearch.getScore(
                    query,
                    document
            );
        }

        return 1.0;
    }

    public ArrayList<WebDocument> getDocuments() {
        return documents;
    }
}