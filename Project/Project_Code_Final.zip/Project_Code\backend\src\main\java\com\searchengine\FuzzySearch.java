package com.searchengine;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * FuzzySearch matches documents even when the query contains misspellings or typos,
 * evaluating edit distance via Dynamic Programming.
 *
 * DSA Concepts Used:
 * - Edit Distance (Levenshtein Distance): 2D Dynamic Programming matrix computing
 *   minimum insertions, deletions, and substitutions in O(m * n).
 * - Multi-word tokenization and HashSet for fast vocabulary lookup.
 * - Bubble Sort: Ranks documents with the lowest cumulative edit distance first.
 */
public class FuzzySearch {

    private TextProcessor processor;
    private EditDistance editDistance;

    public FuzzySearch() {
        this.processor = new TextProcessor();
        this.editDistance = new EditDistance();
    }

    public ArrayList<WebDocument> search(
            String query,
            ArrayList<WebDocument> documents) {

        ArrayList<WebDocument> results = new ArrayList<>();

        if (query == null
                || query.trim().isEmpty()
                || documents == null
                || documents.isEmpty()) {
            return results;
        }

        // Tokenize multi-word query (e.g. ["virat", "koli"], ["machin", "lerning"])
        String[] queryWords = processor.process(query);

        if (queryWords.length == 0) {
            return results;
        }

        ArrayList<WebDocument> matchedDocs = new ArrayList<>();
        ArrayList<Integer> totalDistances = new ArrayList<>();

        for (WebDocument document : documents) {
            // Extract unique words from both title and content to test against
            Set<String> docVocab = new HashSet<>();

            String[] titleWords = processor.process(document.getTitle());
            for (String tw : titleWords) {
                docVocab.add(tw);
            }

            String[] textWords = processor.process(document.getText());
            for (String dw : textWords) {
                docVocab.add(dw);
            }

            int matchedWordCount = 0;
            int docTotalDistance = 0;

            for (String qWord : queryWords) {
                // Exact match check (distance 0)
                if (docVocab.contains(qWord)) {
                    matchedWordCount++;
                    continue;
                }

                // Adaptive threshold: short words (<=4 chars) allow 1 edit, longer allow 2 edits
                int threshold = (qWord.length() <= 4) ? 1 : 2;
                int bestDistForWord = Integer.MAX_VALUE;

                for (String dWord : docVocab) {
                    // Length pruning: Levenshtein distance >= |len(A) - len(B)|
                    if (Math.abs(dWord.length() - qWord.length()) > threshold) {
                        continue;
                    }

                    // DSA: Dynamic Programming Edit Distance calculation
                    int dist = editDistance.calculate(qWord, dWord);

                    if (dist < bestDistForWord) {
                        bestDistForWord = dist;
                        if (bestDistForWord <= 1) {
                            // Close enough, can stop search for this candidate
                            break;
                        }
                    }
                }

                if (bestDistForWord <= threshold) {
                    matchedWordCount++;
                    docTotalDistance += bestDistForWord;
                }
            }

            // Require all query terms (or most for long queries) to have fuzzy matches
            boolean isMatch = (queryWords.length <= 2)
                    ? (matchedWordCount == queryWords.length)
                    : (matchedWordCount >= Math.max(2, (int) Math.ceil(queryWords.length * 0.7)));

            if (isMatch) {
                matchedDocs.add(document);
                totalDistances.add(docTotalDistance);
            }
        }

        // DSA: Bubble Sort to rank documents with smaller edit distance (closer match) first
        for (int i = 0; i < totalDistances.size() - 1; i++) {
            for (int j = 0; j < totalDistances.size() - i - 1; j++) {
                if (totalDistances.get(j) > totalDistances.get(j + 1)) {
                    int tempDist = totalDistances.get(j);
                    totalDistances.set(j, totalDistances.get(j + 1));
                    totalDistances.set(j + 1, tempDist);

                    WebDocument tempDoc = matchedDocs.get(j);
                    matchedDocs.set(j, matchedDocs.get(j + 1));
                    matchedDocs.set(j + 1, tempDoc);
                }
            }
        }

        results.addAll(matchedDocs);
        return results;
    }
}